# SuperAPI Linux 部署包

把 DeepSeek 账号反代成 OpenAI 兼容 API。**单文件服务，无依赖**（静态编译，无需额外运行库）。

## 一分钟部署

```bash
# 1) 拷贝到服务器
scp -r superapi-linux-amd64/ root@YOUR_SERVER:/opt/superapi

# 2) 填凭据（DeepSeek userToken）
ssh root@YOUR_SERVER
cd /opt/superapi
chmod 600 superapi.env
vi superapi.env          # 填 SUPERAPI_TOKEN=你的userToken，改 SUPERAPI_APIKEY=你的访问密钥

# 3) 前台试跑（验证能起来）
./run.sh
#   看到 "SuperAPI Gateway Server Started" 即成功

# 4) 装成 systemd 服务（开机自启 + 崩溃重拉）
cp superapi.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now superapi
systemctl status superapi --no-pager

# 5) 验证
curl http://127.0.0.1:8080/healthz
curl -H "Authorization: Bearer 你的APIKEY" http://127.0.0.1:8080/v1/models
```

## 客户端接入

```
Base URL : http://YOUR_SERVER:8080/v1
API Key  : superapi.env 里 SUPERAPI_APIKEY 的值
Model    : deepseek-v4.1-flash
```

## 端点

| 端点 | 说明 |
|---|---|
| `/v1/chat/completions` | OpenAI 兼容对话（支持 stream） |
| `/v1/models` | 模型列表 |
| `/v1/user`、`/v1/balance` | 账号/余额信息 |
| `/anthropic/v1/messages`、`/v1/messages` | Anthropic 方言 |
| `/api/chat`、`/api/generate`、`/api/tags` | Ollama 方言 |
| `/healthz`、`/status` | 健康与状态 |

## 运维

```bash
journalctl -u superapi -f          # 看日志
systemctl restart superapi         # 重启
vi superapi.env && systemctl restart superapi   # 换 token/端口
```

## 常见问题

- **token 过期**：跑到 `/status` 看账号是否 `is_available`；过期就回 chat.deepseek.com Console 重取 userToken，更新 `superapi.env` 后重启
- **换端口**：改 `SUPERAPI_PORT`，重启
- **多账号池**：`accounts.json` 填多个 credential（token/email/proxy），实现轮询与熔断——此时可不传 `-token`
- **防火墙**：对外暴露前请改掉默认 `SUPERAPI_APIKEY`，并在安全组/防火墙限制来源

## 组成

| 文件 | 作用 |
|---|---|
| `superapi` | 主程序（静态 ELF，零依赖） |
| `config.json` | 激活直通配置 |
| `accounts.json` | 账号池模板（可选） |
| `run.sh` | 启动脚本（读环境变量） |
| `superapi.service` | systemd 单元 |
| `superapi.env` | 环境变量模板 |
