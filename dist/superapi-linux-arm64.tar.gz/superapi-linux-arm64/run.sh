#!/bin/sh
# SuperAPI 反代启动脚本 —— 凭据走环境变量，不落脚本
set -e
DIR=$(cd "$(dirname "$0")" && pwd)

TOKEN="${SUPERAPI_TOKEN:-}"
if [ -z "$TOKEN" ]; then
  if [ -f "$DIR/superapi.env" ]; then
    . "$DIR/superapi.env"
    TOKEN="${SUPERAPI_TOKEN:-}"
  fi
fi
[ -n "$TOKEN" ] || { echo "[FATAL] 未提供 SUPERAPI_TOKEN（DeepSeek 账号 userToken）"; exit 1; }

PORT="${SUPERAPI_PORT:-8080}"
APIKEY="${SUPERAPI_APIKEY:-changeme}"

# 激活直通配置（缺失则补写）
[ -f "$DIR/config.json" ] || printf '{\n  "activated": true,\n  "activationKey": "local"\n}\n' > "$DIR/config.json"

cd "$DIR"
exec ./superapi \
  -host "${SUPERAPI_HOST:-0.0.0.0}" \
  -port "$PORT" \
  -apikey "$APIKEY" \
  -token "$TOKEN" \
  -model "${SUPERAPI_MODEL:-deepseek-v4.1-flash}" \
  ${SUPERAPI_PROXY:+-proxy "$SUPERAPI_PROXY"} \
  -server-only -no-test -log
